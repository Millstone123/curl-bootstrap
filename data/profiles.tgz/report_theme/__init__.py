"""Shared report theme renderer."""


def get_profile():
    return "default"
